-- ============================================================
--  Sistema de Gerenciamento de Estoque
--  V1 — Create full schema
--  PostgreSQL 16+
-- ============================================================

-- ── Extensions ───────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "pgcrypto";  -- gen_random_uuid()

-- ── Schema ───────────────────────────────────────────────────
CREATE SCHEMA IF NOT EXISTS estoque;
SET search_path TO estoque, public;

-- ============================================================
--  ENUMS
-- ============================================================

CREATE TYPE perfil_usuario    AS ENUM ('admin', 'estoquista', 'gerente');
CREATE TYPE status_produto     AS ENUM ('ativo', 'inativo', 'bloqueado');
CREATE TYPE status_serie       AS ENUM ('disponivel', 'reservado', 'expedido', 'descartado');
CREATE TYPE tipo_movimentacao  AS ENUM (
    'entrada_manual', 'entrada_compra',
    'saida_manual', 'saida_venda',
    'transferencia_saida', 'transferencia_entrada',
    'ajuste', 'reserva', 'liberacao_reserva', 'expedicao'
);
CREATE TYPE status_movimentacao   AS ENUM ('pendente', 'confirmado', 'cancelado');
CREATE TYPE status_transferencia  AS ENUM ('pendente', 'em_transito', 'recebida', 'cancelada');
CREATE TYPE status_reserva        AS ENUM ('ativa', 'expedida', 'cancelada');
CREATE TYPE tipo_inventario       AS ENUM ('total', 'parcial_produto', 'parcial_localizacao', 'parcial_categoria');
CREATE TYPE status_inventario     AS ENUM ('aberto', 'em_contagem', 'apurado', 'encerrado');
CREATE TYPE status_ajuste         AS ENUM ('pendente', 'aprovado', 'rejeitado');
CREATE TYPE tipo_alerta           AS ENUM ('estoque_minimo', 'vencimento_proximo', 'produto_vencido');
CREATE TYPE operacao_auditoria    AS ENUM ('INSERT', 'UPDATE', 'DELETE');

-- ============================================================
--  MASTER DATA
-- ============================================================

CREATE TABLE usuarios (
    id          UUID         NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    nome        VARCHAR(150) NOT NULL,
    email       VARCHAR(255) NOT NULL,
    senha_hash  VARCHAR(255) NOT NULL,
    perfil      perfil_usuario NOT NULL,
    ativo       BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_usuarios_email UNIQUE (email)
);

CREATE TABLE depositos (
    id          UUID         NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    codigo      VARCHAR(30)  NOT NULL,
    nome        VARCHAR(150) NOT NULL,
    descricao   TEXT,
    ativo       BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_depositos_codigo UNIQUE (codigo)
);

CREATE TABLE localizacoes (
    id           UUID         NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    deposito_id  UUID         NOT NULL,
    codigo       VARCHAR(50)  NOT NULL,
    descricao    VARCHAR(150),
    ativo        BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_localizacoes_deposito FOREIGN KEY (deposito_id)
        REFERENCES depositos (id),
    CONSTRAINT uq_localizacoes_deposito_codigo UNIQUE (deposito_id, codigo)
);

CREATE TABLE produtos (
    id                 UUID           NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    sku                VARCHAR(60)    NOT NULL,
    nome               VARCHAR(200)   NOT NULL,
    descricao          TEXT,
    unidade_medida     VARCHAR(20)    NOT NULL,
    controle_lote      BOOLEAN        NOT NULL DEFAULT FALSE,
    controle_validade  BOOLEAN        NOT NULL DEFAULT FALSE,
    controle_serie     BOOLEAN        NOT NULL DEFAULT FALSE,
    estoque_minimo     NUMERIC(14, 4) NOT NULL DEFAULT 0 CHECK (estoque_minimo >= 0),
    status             status_produto NOT NULL DEFAULT 'ativo',
    created_at         TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ    NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_produtos_sku UNIQUE (sku),
    -- validade requer lote
    CONSTRAINT ck_produtos_validade_requer_lote
        CHECK (controle_validade = FALSE OR controle_lote = TRUE)
);

CREATE TABLE lotes (
    id               UUID         NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    produto_id       UUID         NOT NULL,
    numero_lote      VARCHAR(100) NOT NULL,
    data_validade    DATE,
    data_fabricacao  DATE,
    criado_em        TIMESTAMPTZ  NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_lotes_produto FOREIGN KEY (produto_id)
        REFERENCES produtos (id),
    CONSTRAINT uq_lotes_produto_numero UNIQUE (produto_id, numero_lote)
);

CREATE TABLE numeros_serie (
    id            UUID         NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    produto_id    UUID         NOT NULL,
    lote_id       UUID,
    numero_serie  VARCHAR(100) NOT NULL,
    status        status_serie NOT NULL DEFAULT 'disponivel',
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_serie_produto FOREIGN KEY (produto_id)
        REFERENCES produtos (id),
    CONSTRAINT fk_serie_lote FOREIGN KEY (lote_id)
        REFERENCES lotes (id),
    CONSTRAINT uq_numeros_serie UNIQUE (numero_serie)
);

-- ============================================================
--  SALDO CONSOLIDADO
-- ============================================================

CREATE TABLE saldos_estoque (
    id               UUID           NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    produto_id       UUID           NOT NULL,
    deposito_id      UUID           NOT NULL,
    localizacao_id   UUID,
    lote_id          UUID,
    qtd_disponivel   NUMERIC(14, 4) NOT NULL DEFAULT 0,
    qtd_reservada    NUMERIC(14, 4) NOT NULL DEFAULT 0,
    qtd_em_transito  NUMERIC(14, 4) NOT NULL DEFAULT 0,
    updated_at       TIMESTAMPTZ    NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_saldo_produto    FOREIGN KEY (produto_id)    REFERENCES produtos (id),
    CONSTRAINT fk_saldo_deposito   FOREIGN KEY (deposito_id)   REFERENCES depositos (id),
    CONSTRAINT fk_saldo_localizacao FOREIGN KEY (localizacao_id) REFERENCES localizacoes (id),
    CONSTRAINT fk_saldo_lote       FOREIGN KEY (lote_id)       REFERENCES lotes (id),

    CONSTRAINT uq_saldo_posicao UNIQUE (produto_id, deposito_id, localizacao_id, lote_id),

    CONSTRAINT ck_saldo_disponivel   CHECK (qtd_disponivel   >= 0),
    CONSTRAINT ck_saldo_reservada    CHECK (qtd_reservada    >= 0),
    CONSTRAINT ck_saldo_em_transito  CHECK (qtd_em_transito  >= 0)
);

-- ============================================================
--  TRANSAÇÕES
-- ============================================================

-- transferencias declared before movimentacoes (FK dependency)
CREATE TABLE transferencias (
    id                   UUID                  NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    produto_id           UUID                  NOT NULL,
    deposito_origem_id   UUID                  NOT NULL,
    deposito_destino_id  UUID                  NOT NULL,
    lote_id              UUID,
    quantidade           NUMERIC(14, 4)        NOT NULL CHECK (quantidade > 0),
    status               status_transferencia  NOT NULL DEFAULT 'pendente',
    usuario_criacao_id   UUID                  NOT NULL,
    usuario_recepcao_id  UUID,
    documento_referencia VARCHAR(100),
    expedido_em          TIMESTAMPTZ,
    recebido_em          TIMESTAMPTZ,
    created_at           TIMESTAMPTZ           NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ           NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_transf_produto  FOREIGN KEY (produto_id)          REFERENCES produtos (id),
    CONSTRAINT fk_transf_origem   FOREIGN KEY (deposito_origem_id)   REFERENCES depositos (id),
    CONSTRAINT fk_transf_destino  FOREIGN KEY (deposito_destino_id)  REFERENCES depositos (id),
    CONSTRAINT fk_transf_lote     FOREIGN KEY (lote_id)              REFERENCES lotes (id),
    CONSTRAINT fk_transf_criacao  FOREIGN KEY (usuario_criacao_id)   REFERENCES usuarios (id),
    CONSTRAINT fk_transf_recepcao FOREIGN KEY (usuario_recepcao_id)  REFERENCES usuarios (id),

    CONSTRAINT ck_transf_depositos_distintos
        CHECK (deposito_origem_id <> deposito_destino_id)
);

CREATE TABLE movimentacoes (
    id                      UUID                  NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    tipo                    tipo_movimentacao     NOT NULL,
    produto_id              UUID                  NOT NULL,
    deposito_origem_id      UUID,
    deposito_destino_id     UUID,
    localizacao_origem_id   UUID,
    localizacao_destino_id  UUID,
    lote_id                 UUID,
    numero_serie_id         UUID,
    transferencia_id        UUID,
    usuario_id              UUID                  NOT NULL,
    quantidade              NUMERIC(14, 4)        NOT NULL CHECK (quantidade > 0),
    documento_referencia    VARCHAR(100),
    motivo                  TEXT,
    status                  status_movimentacao   NOT NULL DEFAULT 'confirmado',
    created_at              TIMESTAMPTZ           NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_mov_produto           FOREIGN KEY (produto_id)             REFERENCES produtos (id),
    CONSTRAINT fk_mov_dep_origem        FOREIGN KEY (deposito_origem_id)      REFERENCES depositos (id),
    CONSTRAINT fk_mov_dep_destino       FOREIGN KEY (deposito_destino_id)     REFERENCES depositos (id),
    CONSTRAINT fk_mov_loc_origem        FOREIGN KEY (localizacao_origem_id)   REFERENCES localizacoes (id),
    CONSTRAINT fk_mov_loc_destino       FOREIGN KEY (localizacao_destino_id)  REFERENCES localizacoes (id),
    CONSTRAINT fk_mov_lote              FOREIGN KEY (lote_id)                 REFERENCES lotes (id),
    CONSTRAINT fk_mov_serie             FOREIGN KEY (numero_serie_id)         REFERENCES numeros_serie (id),
    CONSTRAINT fk_mov_transferencia     FOREIGN KEY (transferencia_id)        REFERENCES transferencias (id),
    CONSTRAINT fk_mov_usuario           FOREIGN KEY (usuario_id)              REFERENCES usuarios (id)
);

CREATE TABLE reservas (
    id               UUID           NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    produto_id       UUID           NOT NULL,
    deposito_id      UUID           NOT NULL,
    lote_id          UUID,
    usuario_id       UUID           NOT NULL,
    quantidade       NUMERIC(14, 4) NOT NULL CHECK (quantidade > 0),
    documento_origem VARCHAR(100),
    status           status_reserva NOT NULL DEFAULT 'ativa',
    created_at       TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ    NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_reserva_produto  FOREIGN KEY (produto_id)  REFERENCES produtos (id),
    CONSTRAINT fk_reserva_deposito FOREIGN KEY (deposito_id) REFERENCES depositos (id),
    CONSTRAINT fk_reserva_lote     FOREIGN KEY (lote_id)     REFERENCES lotes (id),
    CONSTRAINT fk_reserva_usuario  FOREIGN KEY (usuario_id)  REFERENCES usuarios (id)
);

-- ============================================================
--  INVENTÁRIO / AJUSTES
-- ============================================================

CREATE TABLE inventarios (
    id           UUID              NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    usuario_id   UUID              NOT NULL,
    descricao    VARCHAR(255),
    tipo         tipo_inventario   NOT NULL,
    status       status_inventario NOT NULL DEFAULT 'aberto',
    iniciado_em  TIMESTAMPTZ       NOT NULL DEFAULT NOW(),
    encerrado_em TIMESTAMPTZ,
    created_at   TIMESTAMPTZ       NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_inv_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
);

CREATE TABLE inventario_itens (
    id                   UUID           NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    inventario_id        UUID           NOT NULL,
    produto_id           UUID           NOT NULL,
    localizacao_id       UUID,
    lote_id              UUID,
    usuario_contagem_id  UUID,
    qtd_sistema          NUMERIC(14, 4) NOT NULL,
    qtd_contada          NUMERIC(14, 4),
    divergencia          NUMERIC(14, 4) GENERATED ALWAYS AS (qtd_contada - qtd_sistema) STORED,
    contado_em           TIMESTAMPTZ,

    CONSTRAINT fk_invitem_inventario  FOREIGN KEY (inventario_id)       REFERENCES inventarios (id),
    CONSTRAINT fk_invitem_produto     FOREIGN KEY (produto_id)           REFERENCES produtos (id),
    CONSTRAINT fk_invitem_localizacao FOREIGN KEY (localizacao_id)       REFERENCES localizacoes (id),
    CONSTRAINT fk_invitem_lote        FOREIGN KEY (lote_id)              REFERENCES lotes (id),
    CONSTRAINT fk_invitem_usuario     FOREIGN KEY (usuario_contagem_id)  REFERENCES usuarios (id)
);

CREATE TABLE ajustes (
    id                      UUID          NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    inventario_id           UUID,
    produto_id              UUID          NOT NULL,
    deposito_id             UUID          NOT NULL,
    localizacao_id          UUID,
    lote_id                 UUID,
    usuario_solicitante_id  UUID          NOT NULL,
    usuario_aprovador_id    UUID,
    movimentacao_id         UUID,
    quantidade_ajuste       NUMERIC(14, 4) NOT NULL,  -- negativo = saída
    justificativa           TEXT          NOT NULL,
    status                  status_ajuste NOT NULL DEFAULT 'pendente',
    solicitado_em           TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    aprovado_em             TIMESTAMPTZ,

    CONSTRAINT fk_ajuste_inventario   FOREIGN KEY (inventario_id)          REFERENCES inventarios (id),
    CONSTRAINT fk_ajuste_produto      FOREIGN KEY (produto_id)              REFERENCES produtos (id),
    CONSTRAINT fk_ajuste_deposito     FOREIGN KEY (deposito_id)             REFERENCES depositos (id),
    CONSTRAINT fk_ajuste_localizacao  FOREIGN KEY (localizacao_id)          REFERENCES localizacoes (id),
    CONSTRAINT fk_ajuste_lote         FOREIGN KEY (lote_id)                 REFERENCES lotes (id),
    CONSTRAINT fk_ajuste_solicitante  FOREIGN KEY (usuario_solicitante_id)  REFERENCES usuarios (id),
    CONSTRAINT fk_ajuste_aprovador    FOREIGN KEY (usuario_aprovador_id)    REFERENCES usuarios (id),
    CONSTRAINT fk_ajuste_movimentacao FOREIGN KEY (movimentacao_id)         REFERENCES movimentacoes (id),

    CONSTRAINT ck_ajuste_aprovador_com_data
        CHECK (
            (status = 'aprovado' AND usuario_aprovador_id IS NOT NULL AND aprovado_em IS NOT NULL)
            OR status <> 'aprovado'
        )
);

-- ============================================================
--  ALERTAS
-- ============================================================

CREATE TABLE alertas (
    id           UUID        NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    produto_id   UUID        NOT NULL,
    deposito_id  UUID,
    lote_id      UUID,
    tipo         tipo_alerta NOT NULL,
    mensagem     TEXT        NOT NULL,
    resolvido    BOOLEAN     NOT NULL DEFAULT FALSE,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolvido_em TIMESTAMPTZ,

    CONSTRAINT fk_alerta_produto  FOREIGN KEY (produto_id)  REFERENCES produtos (id),
    CONSTRAINT fk_alerta_deposito FOREIGN KEY (deposito_id) REFERENCES depositos (id),
    CONSTRAINT fk_alerta_lote     FOREIGN KEY (lote_id)     REFERENCES lotes (id),

    CONSTRAINT ck_alerta_resolvido_com_data
        CHECK (resolvido = FALSE OR resolvido_em IS NOT NULL)
);

-- ============================================================
--  AUDITORIA (append-only, imutável)
-- ============================================================

CREATE TABLE auditoria (
    id             UUID               NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    usuario_id     UUID,
    tabela         VARCHAR(60)        NOT NULL,
    registro_id    UUID               NOT NULL,
    operacao       operacao_auditoria NOT NULL,
    ip_origem      VARCHAR(45),
    payload_antes  JSONB,
    payload_depois JSONB,
    created_at     TIMESTAMPTZ        NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_auditoria_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
);

-- Prevent UPDATE and DELETE on auditoria via rule
CREATE RULE auditoria_no_update AS ON UPDATE TO auditoria DO INSTEAD NOTHING;
CREATE RULE auditoria_no_delete AS ON DELETE TO auditoria DO INSTEAD NOTHING;

-- ============================================================
--  INDEXES
-- ============================================================

-- usuarios
CREATE INDEX idx_usuarios_perfil   ON usuarios (perfil) WHERE ativo = TRUE;

-- produtos
CREATE INDEX idx_produtos_status   ON produtos (status);
CREATE INDEX idx_produtos_sku      ON produtos (sku);

-- lotes
CREATE INDEX idx_lotes_produto     ON lotes (produto_id);
CREATE INDEX idx_lotes_validade    ON lotes (data_validade) WHERE data_validade IS NOT NULL;

-- numeros_serie
CREATE INDEX idx_serie_produto_status ON numeros_serie (produto_id, status);

-- saldos_estoque
CREATE INDEX idx_saldo_produto     ON saldos_estoque (produto_id);
CREATE INDEX idx_saldo_deposito    ON saldos_estoque (deposito_id);

-- movimentacoes
CREATE INDEX idx_mov_produto       ON movimentacoes (produto_id);
CREATE INDEX idx_mov_dep_origem    ON movimentacoes (deposito_origem_id);
CREATE INDEX idx_mov_dep_destino   ON movimentacoes (deposito_destino_id);
CREATE INDEX idx_mov_lote          ON movimentacoes (lote_id);
CREATE INDEX idx_mov_tipo          ON movimentacoes (tipo);
CREATE INDEX idx_mov_created_at    ON movimentacoes (created_at DESC);
CREATE INDEX idx_mov_doc_ref       ON movimentacoes (documento_referencia) WHERE documento_referencia IS NOT NULL;
CREATE INDEX idx_mov_usuario       ON movimentacoes (usuario_id);

-- transferencias
CREATE INDEX idx_transf_status     ON transferencias (status);
CREATE INDEX idx_transf_origem     ON transferencias (deposito_origem_id);
CREATE INDEX idx_transf_destino    ON transferencias (deposito_destino_id);

-- reservas
CREATE INDEX idx_reserva_produto_dep_status ON reservas (produto_id, deposito_id, status);
CREATE INDEX idx_reserva_doc        ON reservas (documento_origem) WHERE documento_origem IS NOT NULL;

-- inventario_itens
CREATE INDEX idx_invitem_inventario ON inventario_itens (inventario_id);
CREATE INDEX idx_invitem_produto    ON inventario_itens (produto_id);

-- ajustes
CREATE INDEX idx_ajuste_status     ON ajustes (status);
CREATE INDEX idx_ajuste_produto    ON ajustes (produto_id);

-- alertas
CREATE INDEX idx_alerta_tipo_resolvido ON alertas (tipo, resolvido);
CREATE INDEX idx_alerta_produto        ON alertas (produto_id);

-- auditoria
CREATE INDEX idx_audit_tabela_registro ON auditoria (tabela, registro_id);
CREATE INDEX idx_audit_usuario         ON auditoria (usuario_id);
CREATE INDEX idx_audit_created_at      ON auditoria (created_at DESC);

-- ============================================================
--  TRIGGERS — updated_at
-- ============================================================

CREATE OR REPLACE FUNCTION fn_set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_usuarios_updated_at
    BEFORE UPDATE ON usuarios
    FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();

CREATE TRIGGER trg_depositos_updated_at
    BEFORE UPDATE ON depositos
    FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();

CREATE TRIGGER trg_localizacoes_updated_at
    BEFORE UPDATE ON localizacoes
    FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();

CREATE TRIGGER trg_produtos_updated_at
    BEFORE UPDATE ON produtos
    FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();

CREATE TRIGGER trg_transferencias_updated_at
    BEFORE UPDATE ON transferencias
    FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();

CREATE TRIGGER trg_reservas_updated_at
    BEFORE UPDATE ON reservas
    FOR EACH ROW EXECUTE FUNCTION fn_set_updated_at();

-- ============================================================
--  TRIGGER — saldos_estoque updated_at via direct assignment
-- ============================================================

CREATE OR REPLACE FUNCTION fn_saldo_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_saldo_updated_at
    BEFORE UPDATE ON saldos_estoque
    FOR EACH ROW EXECUTE FUNCTION fn_saldo_updated_at();

-- ============================================================
--  COMMENTS
-- ============================================================

COMMENT ON TABLE movimentacoes   IS 'Append-only event log. Fonte de verdade. Nunca UPDATE/DELETE em confirmado.';
COMMENT ON TABLE saldos_estoque  IS 'Projeção materializada do saldo. Atualizada atomicamente na mesma TX da movimentação via SELECT FOR UPDATE.';
COMMENT ON TABLE auditoria       IS 'Imutável. GRANT INSERT apenas. Regras de banco bloqueiam UPDATE/DELETE.';
COMMENT ON TABLE ajustes         IS 'Exige aprovação de gerente antes de efetivar movimentação de ajuste.';
COMMENT ON COLUMN ajustes.quantidade_ajuste IS 'Positivo = entrada de estoque, negativo = saída de estoque.';
COMMENT ON COLUMN inventario_itens.divergencia IS 'Coluna gerada: qtd_contada - qtd_sistema. Calculada automaticamente.';
